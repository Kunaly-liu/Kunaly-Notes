package com.kun.api;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * InetAddress的使用
 */
public class InetAddressDemo {
    public static void main(String[] args) throws UnknownHostException {
        //获取本机的InetAddress对象
        InetAddress localHost = InetAddress.getLocalHost();
        System.out.println(localHost);

        //根据指定主机名 获取InetAddress对象
        InetAddress localHost1 = InetAddress.getByName("LAPTOP-PRHA00NF");
        System.out.println(localHost1);

        //根据域名返回
        InetAddress host = InetAddress.getByName("www.baidu.com");
        System.out.println(host);
        String hostAddress = host.getHostAddress();

        System.out.println("host对应的ip："+hostAddress+"，主机名："+host.getHostName());
    }
}

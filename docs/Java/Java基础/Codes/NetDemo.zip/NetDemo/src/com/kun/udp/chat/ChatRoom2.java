package com.kun.udp.chat;

import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Scanner;

/**
 * 实现聊天窗口界面，首先创建一个名称为ChatRoom的程序入口类,
 * 在该类的main()方法中获取当前服务所在端口号、聊天对象服务所在端口号,
 * 并创建DatagramSocket信息收发对象,以及通过多线程实现发送端和接收端功能
 */
public class ChatRoom2 {
    public static void main(String[] args) {
        @SuppressWarnings("resource")
        Scanner sc = new Scanner(System.in);
        System.out.print("请输入聊天服务当前启动端口号：");
        int serverPort = sc.nextInt();
        System.out.print("请输入聊天服务发送信息对象的目标端口号：");
        int targetPort = sc.nextInt();
        System.out.println("聊天系统初始化完成并启动！！！");
        try {
            DatagramSocket socket = new DatagramSocket(serverPort);
            new Thread(new ChatReceiver(socket), "接收服务").start();
            new Thread(new ChatSend(socket,targetPort),"发送服务").start();
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }
}
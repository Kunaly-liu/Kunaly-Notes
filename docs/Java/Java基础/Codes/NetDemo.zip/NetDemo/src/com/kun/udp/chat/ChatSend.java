package com.kun.udp.chat;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

/**
 * 实现聊天程序发送信息功能
 */
public class ChatSend implements Runnable {
    private DatagramSocket client;
    private int targetPort;
    public ChatSend(DatagramSocket client,int targetPort) {
        this.client = client;
        this.targetPort = targetPort;
    }
    public void run() {
        try {
            @SuppressWarnings("resource")
            Scanner sc = new Scanner(System.in);
            while (true) {
                String data = sc.nextLine();
                byte[] buf = data.getBytes();
                DatagramPacket packet = new DatagramPacket(buf, buf.length,
                        InetAddress.getByName("127.0.0.255"),targetPort);
                client.send(packet);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
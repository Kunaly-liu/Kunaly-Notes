package com.kun.upload;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;

public class TCPFileUploadClient {
    public static void main(String[] args) throws IOException {
        //创建输入流
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream("NetDemo\\src\\com\\kun\\upload\\in.txt"));
        //创建Socket
        Socket client = new Socket("127.0.0.1", 8888);
        //输出流
        BufferedOutputStream bos = new BufferedOutputStream(client.getOutputStream());
        //写出数据
        byte[] b = new byte[1024 * 8];
        int len;
        while ((len = bis.read(b)) != -1) {
            bos.write(b, 0, len);
            bos.flush();
        }
        System.out.println("文件已上传");

        //关闭资源
        bos.close();
        client.close();
        bis.close();
        System.out.println("文件上传完成");
    }
}

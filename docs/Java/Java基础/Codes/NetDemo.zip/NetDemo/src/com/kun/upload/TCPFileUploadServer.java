package com.kun.upload;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPFileUploadServer {
    public static void main(String[] args) throws IOException {
        System.out.println("服务启动，等待连接中");
        //创建ServerSocket对象，绑定端口，开始等待连接
        ServerSocket ss = new ServerSocket(8888);
        //接受accept方法，返回socket对象
        Socket server = ss.accept();
        //获取输入对象，读取文件
        BufferedInputStream bis = new BufferedInputStream(server.getInputStream());
        //保存到本地
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("NetDemo\\src\\com\\kun\\upload\\copy.txt"));

        //创建字节数组
        byte[] b = new byte[1024 * 8];
        //读取字符数组
        int len;
        while ((len = bis.read(b)) != -1) {
            bos.write(b, 0, len);
        }

        //关闭资源
        bos.close();
        bis.close();
        server.close();
        System.out.println("上传成功");
    }
}

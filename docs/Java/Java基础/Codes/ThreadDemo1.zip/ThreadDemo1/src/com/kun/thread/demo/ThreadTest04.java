package com.kun.thread.demo;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

public class ThreadTest04 {
    public static void main(String[] args) {
        //创建 Callable 实现类的实例
         MyCallable myCallable = new MyCallable();
        //使用 FutureTask 类来包装 Callable 对象
        FutureTask<Integer> ft = new FutureTask<>(myCallable);

        //启动分支线程
        new Thread(ft,"有返回值的分支线程").start();

        //主线程
        for (int i = 0; i < 1000; i++) {
            System.out.println("主线程-->" + i);
        }

        //输出分支线程的返回值
        try {
            System.out.println("子线程的返回值："+ft.get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

    }
}

class MyCallable implements Callable{
    @Override
    public Integer call() throws Exception {
        int i = 0;
        for ( ; i < 1000; i++) {
            System.out.println("分支线程-->" + i);
        }
        return i;
    }
}
package com.kun.thread.demo;

public class ThreadTest06 {
    public static void main(String[] args) {
        System.out.println("main begin!");
        Thread f1 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 100; i++) {
                    System.out.println(Thread.currentThread().getName() + "-->" + i + "，优先级：" + Thread.currentThread().getPriority());
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        Thread f2 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 100; i++) {
                    System.out.println(Thread.currentThread().getName() + "-->" + i + "，优先级：" + Thread.currentThread().getPriority());
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        //设置f1线程优先级为最高
        f1.setPriority(10);
        //设置f2线程的优先级为最低
        f2.setPriority(1);
        //启动两个线程
        f1.start();
        f2.start();
    }
}

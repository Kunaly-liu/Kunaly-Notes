package com.kun.thread.demo;

public class ThreadTest012 {
    public static void main(String[] args) {
        Thread myDaemon=new MyDaemon();
        myDaemon.setName("备份数据");
        //设为守护线程
        myDaemon.setDaemon(true);
        myDaemon.start();
        //主线程
        for(int i =0 ;i<10;i++){
            System.out.println(Thread.currentThread().getName()+"-->"+i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
class MyDaemon extends Thread{
    @Override
    public void run() {
        int i = 0;
        //即使是死循环，但由于改线程是守护者，当用户结束，守护线程自动终止。
        while (true) {
            System.out.println(Thread.currentThread().getName() + "-->" + (++i));
            try {
                Thread.sleep(1000);//模拟一秒记录一次
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
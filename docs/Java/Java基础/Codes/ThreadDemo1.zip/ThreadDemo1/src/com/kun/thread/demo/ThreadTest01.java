package com.kun.thread.demo;
//第一种：直接继承 Thread
public class ThreadTest01 {
    public static void main(String[] args) {
        //这里是主线程，在主栈中执行
        //新建一个分支线程
        MyThread myThread = new MyThread();
        //启动线程
        /*start方法的作用:启动一个分支线程，在JVM种开辟一个新的栈空
         间，这段代码完成后瞬间就结束了，线程就启动成功了*/
        /*启动成功的线程会自动调用run方法，并且run方法在分支栈的底部
        run和main方法平级*/
        myThread.start();
        //myThread.run();//不会启动动线程（为单线程）
        for(int i=0 ;i<100;i++){
            System.out.println("主线程--->"+i);
        }
    }
}

class MyThread extends Thread{
    @Override
    public void run() {
        //编写代码，这段程序在分支线程中执行
        for(int i=0 ;i<100;i++){
            System.out.println("分支线程--->"+i);
        }
    }
}

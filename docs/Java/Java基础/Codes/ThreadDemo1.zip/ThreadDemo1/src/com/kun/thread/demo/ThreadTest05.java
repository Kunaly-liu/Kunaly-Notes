package com.kun.thread.demo;

public class ThreadTest05 {
    public static void main(String[] args) {
        //以下代码出现在main方法中，所以当前线程就是主线程，获取当前线程对象
        Thread current1 = Thread.currentThread();
        System.out.println(current1.getName());
        //创建线程对象
        MyThread2 t1 = new MyThread2();
        //设置线程的名字
        t1.setName("sss");
        //获取线程的名字
        System.out.println(t1.getName());
        //创建线程对象
        MyThread2 t2 = new MyThread2();
        System.out.println(t2.getName());
        //启动线程
        t1.start();
        for(int i=0;i<10;i++){
            Thread current2 = Thread.currentThread();
            System.out.println(current2.getName()+"-->"+i);
        }
    }
}
class  MyThread2 extends Thread{
    @Override
    public void run() {
        //获取当前对象
        for (int i =0;i<1000;i++){
            //获取当前线程对象
            Thread current2 = Thread.currentThread();
            System.out.println(current2.getName()+"--->"+i);
        }
    }
}
package com.kun.thread.demo;

public class ThreadTest07 {
    public static void main(String[] args) {
        System.out.println("main begin!");
        Thread f = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 100; i++) {
                    System.out.println(Thread.currentThread().getName() + "-->" + i);
                }
            }
        });
        f.setName("ttt");
        f.start();
        //合并到当前线程，当前线程受到阻塞，直到f线程执行结束
        try {
            f.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("main over!");
    }
}

package com.kun.thread.demo;

public class ThreadTest09 { public static void main(String[] args) {
    Thread t =new Thread(new Runnable() {//匿名内部类实现接口
        @Override
        public void run() {
            try {
                Thread.sleep(1000*60*60);
            } catch (InterruptedException e) {//interrupted()方法引发这个异常
                e.printStackTrace();
            }
            System.out.println("Hello Wrold!");
        }
    });
    t.setName("se");
    t.start();
    t.interrupt();//中断阻塞
}
}
import org.junit.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * 此类用于演示批处理
 * 情况1：多条sql语句的批量执行【较少使用】
 * Statement+批处理：提高了执行的效率，并没有减少编译的次数
 * 情况2：一条sql语句的批量传参【较多使用】
 * PreparedStatement+批处理：减少了执行的次数，也减少了编译的次数，大大提高效率
 * 相关API：
 * 	addBatch()
 * 	executeBatch()
 * 	clearBatch()
 * 注意：
 * 	①需要在url添加reWriteBatchedStatement = true
 *   驱动类使用的版本：8.0.21 但不能使用5.1.7（不支持批处理）
 *  ②插入时，使用values，而不是value！
 *案例：添加50000条用户记录
 */

public class TestBatch {
    //没有使用批处理
    @Test
    public void testNoBatch() throws Exception {
        long start = System.currentTimeMillis();
        //1.获取连接
        Connection connection = JDBCUtils.getConnection();
        //2.执行插入
        PreparedStatement statement = connection.prepareStatement("insert into user values(NULL,?,?,?)");
        for(int i=1;i<=50000;i++) {
            statement.setString(1, "john"+i);
            statement.setInt(2, 0);
            statement.setString(3, "男");
            statement.executeUpdate();
        }
        //3.关闭
        JDBCUtils.close(null, statement, connection);
        long end = System.currentTimeMillis();
        System.out.println("没有使用批处理耗时：" + (end-start));
    }
    //使用批处理
    @Test
    public void testUseBatch() throws Exception {
        long start = System.currentTimeMillis();
        //1.获取连接
        Connection connection = JDBCUtils.getConnection();
        //2.执行插入
        PreparedStatement statement = connection.prepareStatement("insert into user values(NULL,?,?,?)");
        for(int i=1;i<=50000;i++) {
            statement.setString(1, "john"+i);
            statement.setInt(2, 0);
            statement.setString(3, "女");
            //添加到批处理包（放到框中）
            statement.addBatch();
            if(i%1000==0) {
                statement.executeBatch();//执行批处理包的sql(将框中的苹果们运到了楼上)
                statement.clearBatch();//清空批处理包的sql(卸货)
            }
        }
        //3.关闭
        JDBCUtils.close(null, statement, connection);
        long end = System.currentTimeMillis();
        System.out.println("使用批处理耗时：" + (end-start));
    }
}

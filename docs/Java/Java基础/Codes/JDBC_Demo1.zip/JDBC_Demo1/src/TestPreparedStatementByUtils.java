import org.junit.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

/**
 * 一、向user表中插入数据，效果如下：
 请输入编号：13
 请输入姓名：张三丰
 请输入年龄：200
 请输入性别：男
 插入成功！
 */
public class TestPreparedStatementByUtils {
    //增删改
    @Test
    public void test1() throws Exception {
        Scanner input = new Scanner(System.in);
        System.out.println("请输入编号：");
        int id = input.nextInt();
        System.out.println("请输入姓名：");
        String name = input.next();
        System.out.println("请输入年龄：");
        int age = input.nextInt();
        System.out.println("请输入性别：");
        String sex = input.next();

        //-----------------------------连接数据库的步骤-----------------
        //1.获取连接
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=CONVERT_TO_NULL&useSSL=false&serverTimezone=Asia/Shanghai",
                "root", "123456");
        //2、执行插入
        PreparedStatement statement = connection.prepareStatement("insert into user values(?,?,?,?)");
        statement.setInt(1, id);
        statement.setString(2, name);
        statement.setInt(3, age);
        statement.setString(4, sex);
        int update = statement.executeUpdate();
        System.out.println(update>0?"插入成功":"插入失败");
        //3.关闭
        statement.close();
        connection.close();
    }
    //查询
    @Test
    public void test2() throws Exception {
//		请输入编号：13
        Scanner input = new Scanner(System.in);
        System.out.println("请输入编号：");
        int id = input.nextInt();
        //-----------------------------连接数据库的步骤-----------------
        //1.获取连接
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=CONVERT_TO_NULL&useSSL=false&serverTimezone=Asia/Shanghai",
                "root", "123456");
        //2、执行查询
        PreparedStatement statement = connection.prepareStatement(
                "select id,name,age,sex from user where id = ?");
        statement.setInt(1, id);
        ResultSet set = statement.executeQuery();
        if(set.next()) {
            String name = set.getString(2);
            int age = set.getInt(3);
            String sex = set.getString(4);
            System.out.println(id+"\t"+name+"\t"+age+"\t"+sex);
        }
        //3.关闭
        set.close();
        statement.close();
        connection.close();
    }
}
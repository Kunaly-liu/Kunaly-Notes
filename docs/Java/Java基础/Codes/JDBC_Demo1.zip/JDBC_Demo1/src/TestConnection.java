import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 此类用于演示JDBC使用的简单步骤
 * 前提：
 * ①新建文件夹libs,将mysql-connector-java-8.0.21.jar复制到项目的libs目录
 * ②右击mysql-connector-java-8.0.21.jar,选择Add as Library...添加成库。
 */
public class TestConnection {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        // 1.加载驱动（准备工作）
        Class.forName("com.mysql.cj.jdbc.Driver");
        // 2.获取连接
        /*
         * 参数1：url
         * 格式：jdbc:mysql://主机名:端口号/库名
         * 参数2：用户名
         * 参数3：密码
         */
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=CONVERT_TO_NULL&useSSL=false&serverTimezone=Asia/Shanghai",
                "root", "123456");
        // 3.执行增删改查★
        //①获取执行sql语句的命令对象
        Statement statement = connection.createStatement();
        //②执行sql语句
        int update = statement.executeUpdate("delete from user where id=13");
        //③处理结果
        System.out.println(update>0?"success":"failure");
        // 4.关闭连接
        statement.close();
        connection.close();
    }
}

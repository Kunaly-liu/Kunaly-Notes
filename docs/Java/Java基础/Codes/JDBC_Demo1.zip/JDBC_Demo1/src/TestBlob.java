import org.junit.Test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * 此类用于演示Blob类型数据的读写
 * 注意：只能使用PreparedStatement实现Blob类型的读写，不能使用Statement
 * 相关API：
 * 	setBlob(占位符索引，InputStream)
 * 	InputStream is =getBinaryStream(列索引)
 */
public class TestBlob {
    //测试Blob类型数据的写入：修改小苍的照片为指定照片
    @Test
    public void test1() throws Exception {
        //1.获取连接
        Connection connection = JDBCUtils.getConnection();
        //2.执行修改
        PreparedStatement statement = connection.prepareStatement("update userwithphoto set photo = ? where name = ?");
        FileInputStream fileInputStream = new FileInputStream("Resources\\a.jpg");
        statement.setBlob(1, fileInputStream);
        statement.setString(2, "小苍");
        int update = statement.executeUpdate();
        System.out.println(update>0?"插入成功":"插入失败");
        //3.关闭
        JDBCUtils.close(null, statement, connection);
    }
    //测试Blob类型数据的读取：将小苍的图片读取到项目的根目录下
    @Test
    public void test2() throws Exception {
        //1.获取连接
        Connection connection = JDBCUtils.getConnection();
        //2.执行查询
        PreparedStatement statement = connection.prepareStatement("select photo from userwithphoto where name = ?");
        statement.setString(1, "小苍");
        ResultSet set = statement.executeQuery();
        if(set.next()) {
//			Blob blob = set.getBlob(1);
//			InputStream binaryStream = blob.getBinaryStream();
            InputStream inputStream = set.getBinaryStream(1);
            FileOutputStream fos = new FileOutputStream("src\\beauty.jpg");
            //边读边写：复制图片
            byte[] b = new byte[1024];
            int len;
            while((len=inputStream.read(b))!=-1) {
                fos.write(b, 0, len);
            }
            fos.close();
            inputStream.close();
        }
        //3.关闭连接资源
        JDBCUtils.close(set, statement, connection);
    }
}

import org.junit.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TestTransaction {
    @Test
    public void testTransaction() {
        //1.获取连接
        Connection connection = null;
        //事务使用步骤二：编写事务的语句
        //2.执行增删改查
        PreparedStatement statement = null;
        try {
            connection = JDBCUtils.getConnection();
            //事务使用步骤一：开启事务
            connection.setAutoCommit(false);//取消了事务的自动提交+开启事务
            statement = connection.prepareStatement("update account set balance = ? where username = ?");
            statement.setDouble(1, 995);
            statement.setString(2, "张三");
            statement.executeUpdate();
            int i=1/0;
            //操作2：李四的钱多5块
            statement.setDouble(1, 1005);
            statement.setString(2, "李四");
            statement.executeUpdate();
            //事务使用步骤三：结束事务
            connection.commit();//如果执行到该处，说明上面操作没有异常，则可以正常提交事务
        } catch (Exception e) {
            try {
                connection.rollback();//如果执行到该处，说明try块操作有异常，则需要回滚！
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
        finally {
            //3.关闭连接
            JDBCUtils.close(null, statement, connection);
        }
    }
}

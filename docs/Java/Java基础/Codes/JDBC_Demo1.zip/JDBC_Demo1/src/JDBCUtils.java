import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.mchange.v2.c3p0.ComboPooledDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 * jdbc工具类
 */
public class JDBCUtils {
    static DataSource dataSource;
    static {
        try {
            Properties properties = new Properties();
            properties.load(JDBCUtils.class.getClassLoader().getResourceAsStream("druid.properties"));
            dataSource = DruidDataSourceFactory.createDataSource(properties);
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
    //使用druid获取连接
    public static Connection getConnection() throws Exception  {
        return dataSource.getConnection();
    }
    //使用c3p0获取连接
    public static Connection getConnection2() throws SQLException {
        ComboPooledDataSource cpds = new ComboPooledDataSource("hello");
        return cpds.getConnection();
    }
    //释放连接资源
    public static void close(ResultSet set, Statement statement, Connection connection){
        try {
            if(set!=null)
                set.close();
            if(statement!=null)
                statement.close();
            if(connection!=null)
                connection.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

